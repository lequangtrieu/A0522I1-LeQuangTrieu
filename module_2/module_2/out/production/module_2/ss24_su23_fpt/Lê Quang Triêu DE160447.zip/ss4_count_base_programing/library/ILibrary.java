package ss24_su23_fpt.ss4_count_base_programing.library;

public interface ILibrary {
    void countNumber();
    void baseNumber();
}
