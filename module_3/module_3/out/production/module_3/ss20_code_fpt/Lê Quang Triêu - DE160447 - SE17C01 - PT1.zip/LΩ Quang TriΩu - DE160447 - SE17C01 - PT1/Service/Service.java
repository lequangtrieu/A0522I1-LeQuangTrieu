package ss20_code_fpt.Progress1.Service;

public interface Service {
    void input();
    void display();

    void checkAddress();
}
