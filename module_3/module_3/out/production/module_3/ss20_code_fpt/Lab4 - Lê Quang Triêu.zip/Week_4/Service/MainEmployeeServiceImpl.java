package ss20_code_fpt.Week_4.Service;

import ss20_code_fpt.Week_4.Model.MainEmployee;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainEmployeeServiceImpl implements MainEmployeeService{
    private static final Scanner input = new Scanner(System.in);

    private static List<MainEmployee> list = new ArrayList<>();
    @Override
    public void input() {
        MainEmployee mainEmployee = this.info();
        list.add(mainEmployee);
        System.out.println("input successfully!");
    }

    @Override
    public void display() {
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
        System.out.println("display successfully");
    }

    @Override
    public void calculate() {
        double total = 0;
        for (int i = 0; i < list.size(); i++) {
            total += list.get(i).getSalary();
        }
        System.out.println(total);
    }


    private MainEmployee info() {
        System.out.println("id:");
        String id = input.nextLine();
        System.out.println("lastname:");
        String lastname = input.nextLine();
        System.out.println("firstname:");
        String firstname = input.nextLine();
        System.out.println("birthday:");
        LocalDate birthday = LocalDate.parse(input.nextLine());
        System.out.println("amountDayOfWork:");
        double amountDayOfWork = Double.parseDouble(input.nextLine());
        System.out.println("timeOT:");
        double timeOT = Double.parseDouble(input.nextLine());
        double salary = (amountDayOfWork * 1000000) + (timeOT * 100000);

        MainEmployee mainEmployee = new MainEmployee(id, lastname, firstname, birthday, amountDayOfWork, timeOT, salary);
        return mainEmployee;
    }
}
