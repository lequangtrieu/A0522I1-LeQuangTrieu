package ss20_code_fpt.Week_4.Service;

public interface Service {
    void input();
    void display();
    void calculate();
}
