package ss20_code_fpt.Week_4.Service;

import ss20_code_fpt.Week_4.Model.PartTimeEmployee;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PartTimeEmployeeServiceImpl implements PartTimeEmployeeService{
    private static final Scanner input = new Scanner(System.in);

    private static List<PartTimeEmployee> list = new ArrayList<>();
    @Override
    public void input() {
        PartTimeEmployee partTimeEmployee = this.info();
        list.add(partTimeEmployee);
        System.out.println("input successfully!");
    }

    @Override
    public void display() {
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
        System.out.println("display successfully");
    }

    @Override
    public void calculate() {
        double total = 0;
        for (int i = 0; i < list.size(); i++) {
            total += list.get(i).getSalary();
        }
        System.out.println(total);
    }

    private PartTimeEmployee info() {
        System.out.println("id:");
        String id = input.nextLine();
        System.out.println("lastname:");
        String lastname = input.nextLine();
        System.out.println("firstname:");
        String firstname = input.nextLine();
        System.out.println("birthday:");
        LocalDate birthday = LocalDate.parse(input.nextLine());
        System.out.println("amountDayOfWork:");
        double amountDayOfWork = Double.parseDouble(input.nextLine());
        double salary = amountDayOfWork * 1000000 * 0.5;

        PartTimeEmployee partTimeEmployee = new PartTimeEmployee(id, lastname, firstname, birthday, amountDayOfWork, salary);
        return partTimeEmployee;
    }
}
