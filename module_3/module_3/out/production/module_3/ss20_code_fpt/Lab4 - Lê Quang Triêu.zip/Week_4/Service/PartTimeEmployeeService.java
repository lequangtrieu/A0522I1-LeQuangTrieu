package ss20_code_fpt.Week_4.Service;

public interface PartTimeEmployeeService extends Service{
}
