package ss20_code_fpt.Week_1.Lab1A;

import java.util.Scanner;

public class PrintMarkMoreFiveDemo {
    private static final Scanner input = new Scanner(System.in);
//    private static double[] printMArk(double[] arr) {
//        int size = 0;
//        int index = 0;
//        double[] result = new double[size];
//        for (int i = 0; i < arr.length; i++) {
//            if (arr[i] > 10 || arr[i] < 0) {
//                return null;
//            }
//            if (arr[i] >= 5) {
//                size++;
//                result[index] = arr[i];
//                index++;
//            }
//        }
//        if (result == null) {
//            return null;
//        } else {
//            return result;
//        }
//    } lỗi array null

    public static void main(String[] args) {

//        double[] arr = {2, 5, 1, 5.5, 8,};
//        if (printMArk(arr) == null) {
//            System.out.println("null");
//        } else {
//            for (int i = 0; i < printMArk(arr).length; i++) {
//                System.out.println(printMArk(arr)[i]);
//            }
//        }
//  lỗi array null
    }
}
