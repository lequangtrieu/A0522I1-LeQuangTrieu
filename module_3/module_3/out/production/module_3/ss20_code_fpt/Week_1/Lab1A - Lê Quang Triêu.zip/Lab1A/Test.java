package ss20_code_fpt.Week_1.Lab1A;

public class Test {
    public static void main(String[] args) {
        double a = 8.99999;

        System.out.println((int)a);
    }
}
