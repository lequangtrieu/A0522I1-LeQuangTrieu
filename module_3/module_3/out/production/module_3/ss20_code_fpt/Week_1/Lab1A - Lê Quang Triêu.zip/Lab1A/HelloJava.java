package ss20_code_fpt.Week_1.Lab1A;

public class HelloJava {
    public static void main(String[] args) {
        String name = "Lê Quang Triêu";
        System.out.println("Welcome " + name);
    }
}
