package ss20_code_fpt.Week_1.Lab1A;

import java.util.Scanner;

public class PrintDivisor {
    private static final Scanner input = new Scanner(System.in);
    private static void printDivisor(int n) {
        for (int i = 1; i <= n; i++) {
            if (n % i == 0) {
                System.out.println(i);
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("enter n:");
        int n = Integer.parseInt(input.nextLine());
        printDivisor(n);
    }
}
