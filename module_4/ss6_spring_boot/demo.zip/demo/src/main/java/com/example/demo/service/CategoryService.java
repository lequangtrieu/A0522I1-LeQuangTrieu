package com.example.demo.service;

import com.example.demo.model.Category;

public interface CategoryService extends Service<Category> {
}
