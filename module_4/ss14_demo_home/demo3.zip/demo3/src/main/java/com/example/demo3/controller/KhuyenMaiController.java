package com.example.demo3.controller;

import com.example.demo3.model.KhuyenMai;
import com.example.demo3.service.KhuyenMaiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

@Controller
@RequestMapping("/km")
public class KhuyenMaiController {
    @Autowired
    KhuyenMaiService khuyenMaiService;
    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("khuyenmais", khuyenMaiService.findAll());
        return "view/list";
    }
    @GetMapping("/create")
    public String showCreate(Model model) {
        KhuyenMai khuyenMai = new KhuyenMai();
        model.addAttribute("khuyenmai", khuyenMai);
        return "view/create";
    }
    @PostMapping("/create")
    public String doCreate(@Valid @ModelAttribute KhuyenMai khuyenMai,
                           BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return "view/create";
        }
        khuyenMaiService.create(khuyenMai);
        return "redirect:/km/list";
    }
}
