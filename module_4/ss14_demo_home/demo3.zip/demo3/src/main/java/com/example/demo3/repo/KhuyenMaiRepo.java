package com.example.demo3.repo;

import com.example.demo3.model.KhuyenMai;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KhuyenMaiRepo extends JpaRepository<KhuyenMai, Integer> {
}
