package com.example.final_md4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalMd4Application {

    public static void main(String[] args) {
        SpringApplication.run(FinalMd4Application.class, args);
    }

}
